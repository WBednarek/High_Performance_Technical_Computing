#pragma once

#include <cmath>

/**
@brief Class 

*/
class MathFunctions {
public:
    MathFunctions();

    ~MathFunctions();


    static int sign(double x);

    static bool compareTwoAbsElements(double first, double second);

};

